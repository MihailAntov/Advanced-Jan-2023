﻿using System;
namespace GenericScale
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}