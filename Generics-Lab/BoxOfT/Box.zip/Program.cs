﻿using System;
namespace BoxOfT
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}